#!/usr/bin/env python3
"""
月度学习计划生成器 - "月学越厉害"技能核心脚本
根据用户输入的月度主题生成详细学习计划
"""

import json
import datetime
import re
from typing import List, Dict, Any, Tuple
import calendar

class MonthlyLearningPlanGenerator:
    """月度学习计划生成器"""
    
    def __init__(self, year: int = None):
        """初始化生成器"""
        self.year = year or datetime.datetime.now().year
        
        # 学习强度等级配置
        self.intensity_levels = {
            'easy': {'daily_minutes': 15, 'points_per_day': 2, 'weekends_active': False},
            'standard': {'daily_minutes': 30, 'points_per_day': 3, 'weekends_active': True},
            'intensive': {'daily_minutes': 45, 'points_per_day': 4, 'weekends_active': True}
        }
        
        # 学习阶段配置
        self.learning_phases = [
            {"name": "基础概念建立", "focus": "核心术语、基本原理、知识框架"},
            {"name": "核心技能掌握", "focus": "关键方法、实操技巧、工具使用"},
            {"name": "深度应用探索", "focus": "复杂场景、高级技巧、问题解决"},
            {"name": "成果整合展示", "focus": "知识整合、成果产出、能力评估"}
        ]
    
    def parse_monthly_themes(self, themes_input: str) -> List[Dict[str, Any]]:
        """
        解析用户输入的月度主题
        格式示例: "4月：红酒学习\n5月：投资学习\n6月：社保学习"
        
        Args:
            themes_input: 用户输入的月度主题字符串
            
        Returns:
            解析后的月度主题列表
        """
        monthly_themes = []
        
        # 清理输入字符串
        cleaned_input = themes_input.strip()
        
        # 分割成多行
        lines = [line.strip() for line in cleaned_input.split('\n') if line.strip()]
        
        for line in lines:
            # 支持多种分隔符：中文冒号、英文冒号、空格
            if '：' in line:
                separator = '：'
            elif ':' in line:
                separator = ':'
            else:
                # 尝试用空格分割
                parts = line.split()
                if len(parts) >= 2:
                    month_part = parts[0]
                    theme_part = ' '.join(parts[1:])
                    monthly_themes.append(self._parse_single_theme(month_part, theme_part))
                continue
            
            parts = line.split(separator, 1)
            if len(parts) == 2:
                month_part = parts[0].strip()
                theme_part = parts[1].strip()
                monthly_themes.append(self._parse_single_theme(month_part, theme_part))
        
        # 按月份排序
        monthly_themes.sort(key=lambda x: x['month'])
        
        return monthly_themes
    
    def _parse_single_theme(self, month_str: str, theme: str) -> Dict[str, Any]:
        """解析单个月份主题"""
        # 提取月份数字
        month_num = self._extract_month_number(month_str)
        
        if not month_num:
            raise ValueError(f"无法解析月份: {month_str}")
        
        return {
            'month': month_num,
            'month_name': self._get_month_name(month_num),
            'theme': theme,
            'year': self.year
        }
    
    def _extract_month_number(self, month_str: str) -> int:
        """从月份字符串中提取月份数字"""
        # 中文月份映射
        chinese_months = {
            '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6,
            '七': 7, '八': 8, '九': 9, '十': 10, '十一': 11, '十二': 12,
            '一月': 1, '二月': 2, '三月': 3, '四月': 4, '五月': 5, '六月': 6,
            '七月': 7, '八月': 8, '九月': 9, '十月': 10, '十一月': 11, '十二月': 12
        }
        
        # 尝试匹配中文月份
        for chinese, num in chinese_months.items():
            if chinese in month_str:
                return num
        
        # 尝试匹配阿拉伯数字
        import re
        num_match = re.search(r'(\d+)', month_str)
        if num_match:
            month_num = int(num_match.group(1))
            if 1 <= month_num <= 12:
                return month_num
        
        return 0
    
    def _get_month_name(self, month_num: int) -> str:
        """获取月份中文名称"""
        month_names = [
            "一月", "二月", "三月", "四月", "五月", "六月",
            "七月", "八月", "九月", "十月", "十一月", "十二月"
        ]
        return month_names[month_num - 1] if 1 <= month_num <= 12 else f"{month_num}月"
    
    def generate_plan(self, themes_input: str, intensity: str = 'standard') -> Dict[str, Any]:
        """
        生成完整的学习计划
        
        Args:
            themes_input: 用户输入的月度主题
            intensity: 学习强度 (easy/standard/intensive)
            
        Returns:
            完整的学习计划
        """
        # 验证学习强度
        if intensity not in self.intensity_levels:
            intensity = 'standard'
        
        intensity_config = self.intensity_levels[intensity]
        
        # 解析主题
        monthly_themes = self.parse_monthly_themes(themes_input)
        
        if not monthly_themes:
            raise ValueError("无法解析任何月度主题")
        
        # 生成各月计划
        monthly_plans = {}
        for theme_info in monthly_themes:
            month_key = f"{theme_info['year']}-{theme_info['month']:02d}"
            monthly_plans[month_key] = self._generate_single_month_plan(theme_info, intensity_config)
        
        # 构建完整计划
        full_plan = {
            'metadata': {
                'skill_name': '月学越厉害',
                'year': self.year,
                'intensity': intensity,
                'intensity_config': intensity_config,
                'generated_at': datetime.datetime.now().isoformat(),
                'total_months': len(monthly_themes),
                'total_days': sum(len(plan['daily_plans']) for plan in monthly_plans.values())
            },
            'monthly_themes': monthly_themes,
            'monthly_plans': monthly_plans
        }
        
        return full_plan
    
    def _generate_single_month_plan(self, theme_info: Dict, intensity_config: Dict) -> Dict[str, Any]:
        """生成单个月份的学习计划"""
        year = theme_info['year']
        month = theme_info['month']
        
        # 计算月份信息
        month_name = theme_info['month_name']
        theme = theme_info['theme']
        
        # 获取该月的天数
        _, days_in_month = calendar.monthrange(year, month)
        
        # 生成每日计划
        daily_plans = []
        weekly_groups = {}
        
        # 将天数分配到四周
        weeks = self._split_days_into_weeks(days_in_month)
        
        for week_num, week_days in enumerate(weeks, 1):
            week_phase = self.learning_phases[min(week_num - 1, len(self.learning_phases) - 1)]
            
            week_daily_plans = []
            for day in week_days:
                daily_plan = self._generate_daily_plan(
                    year, month, day, week_num, week_phase, theme_info, intensity_config
                )
                daily_plans.append(daily_plan)
                week_daily_plans.append(daily_plan)
            
            weekly_groups[f"week{week_num}"] = {
                'phase': week_phase['name'],
                'focus': week_phase['focus'],
                'days': week_days,
                'daily_plans': week_daily_plans
            }
        
        # 生成学习目标
        learning_objectives = self._generate_learning_objectives(theme)
        
        return {
            'month_info': {
                'year': year,
                'month': month,
                'month_name': month_name,
                'theme': theme,
                'days_in_month': days_in_month
            },
            'daily_plans': daily_plans,
            'weekly_plans': weekly_groups,
            'learning_objectives': learning_objectives,
            'phase_progression': [
                {'week': i+1, 'phase': phase['name'], 'focus': phase['focus']}
                for i, phase in enumerate(self.learning_phases[:len(weeks)])
            ]
        }
    
    def _split_days_into_weeks(self, days_in_month: int) -> List[List[int]]:
        """将月份的天数分配到四周"""
        weeks = []
        current_week = []
        
        for day in range(1, days_in_month + 1):
            current_week.append(day)
            
            # 每周7天，或者到达月末
            if len(current_week) == 7 or day == days_in_month:
                weeks.append(current_week)
                current_week = []
        
        return weeks
    
    def _generate_daily_plan(self, year: int, month: int, day: int,
                            week_number: int, week_phase: Dict,
                            theme_info: Dict, intensity_config: Dict) -> Dict[str, Any]:
        """生成每日学习计划"""
        # 计算日期信息
        date_obj = datetime.date(year, month, day)
        weekday = date_obj.weekday()  # 0=周一, 6=周日
        date_str = date_obj.isoformat()
        
        # 确定学习类型
        if weekday == 5:  # 周六
            learning_type = "知识复习和巩固"
            task_type = "review"
        elif weekday == 6:  # 周日
            learning_type = "综合应用或项目实践"
            task_type = "practice"
        else:  # 工作日
            learning_type = "新知识学习"
            task_type = "learning"
        
        # 生成每日主题
        daily_theme = self._generate_daily_theme(
            theme_info['theme'], week_number, day, week_phase['name']
        )
        
        # 生成知识点
        knowledge_points = []
        for i in range(intensity_config['points_per_day']):
            point_num = i + 1
            knowledge_points.append({
                'id': point_num,
                'title': f"{daily_theme} - 知识点{point_num}",
                'description': self._generate_knowledge_point_description(
                    theme_info['theme'], daily_theme, point_num, week_phase['name']
                ),
                'key_insights': [
                    f"这是关于{daily_theme}的重要概念",
                    f"掌握这个知识点有助于理解{theme_info['theme']}",
                    f"在实际应用中需要注意的关键点"
                ],
                'reference_links': [
                    f"https://example.com/reference/{theme_info['theme']}/{day}_{point_num}_1",
                    f"https://example.com/guide/{theme_info['theme']}/{day}_{point_num}_2"
                ]
            })
        
        # 生成学习任务
        tasks = [
            f"阅读核心知识点（{intensity_config['daily_minutes']}分钟）",
            "完成思考题",
            "记录学习笔记"
        ]
        
        # 生成思考问题
        thinking_questions = [
            f"如何将{daily_theme}应用到实际工作中？",
            f"{daily_theme}与其他相关知识有什么联系？",
            f"学习{daily_theme}对你的职业发展有什么帮助？"
        ]
        
        # 构建每日计划
        return {
            'date': date_str,
            'year': year,
            'month': month,
            'day': day,
            'week_number': week_number,
            'weekday': weekday,
            'weekday_name': ['周一', '周二', '周三', '周四', '周五', '周六', '周日'][weekday],
            'phase': week_phase['name'],
            'learning_type': learning_type,
            'task_type': task_type,
            'daily_theme': daily_theme,
            'learning_minutes': intensity_config['daily_minutes'],
            'knowledge_points': knowledge_points,
            'learning_objective': f"掌握{daily_theme}的核心概念和基本应用",
            'tasks': tasks,
            'thinking_questions': thinking_questions,
            'status': 'pending',  # 未开始
            'completed': False,
            'notes': '',  # 用户学习笔记
            'difficulty_rating': None,  # 难度评分
            'understanding_level': None  # 理解程度
        }
    
    def _generate_daily_theme(self, monthly_theme: str, week_number: int, 
                             day: int, phase: str) -> str:
        """生成每日学习主题"""
        # 根据学习阶段生成主题
        themes_by_phase = {
            "基础概念建立": [
                f"{monthly_theme}概述",
                f"{monthly_theme}基本概念",
                f"{monthly_theme}核心术语",
                f"{monthly_theme}知识框架",
                f"{monthly_theme}发展历史",
                f"{monthly_theme}重要性分析",
                f"{monthly_theme}应用场景"
            ],
            "核心技能掌握": [
                f"{monthly_theme}基本方法",
                f"{monthly_theme}实操技巧",
                f"{monthly_theme}工具使用",
                f"{monthly_theme}常见问题",
                f"{monthly_theme}解决方案",
                f"{monthly_theme}最佳实践",
                f"{monthly_theme}效率提升"
            ],
            "深度应用探索": [
                f"{monthly_theme}高级技巧",
                f"{monthly_theme}复杂场景",
                f"{monthly_theme}案例分析",
                f"{monthly_theme}问题解决",
                f"{monthly_theme}创新应用",
                f"{monthly_theme}趋势分析",
                f"{monthly_theme}未来展望"
            ],
            "成果整合展示": [
                f"{monthly_theme}知识整合",
                f"{monthly_theme}成果总结",
                f"{monthly_theme}项目实践",
                f"{monthly_theme}能力评估",
                f"{monthly_theme}学习反思",
                f"{monthly_theme}持续改进",
                f"{monthly_theme}计划调整"
            ]
        }
        
        # 获取对应阶段的主题列表
        phase_themes = themes_by_phase.get(phase, [])
        
        # 如果没有主题，使用默认主题
        if not phase_themes:
            return f"{monthly_theme}专题学习"
        
        # 根据天数选择主题
        day_index = (day - 1) % len(phase_themes)
        return phase_themes[day_index]
    
    def _generate_knowledge_point_description(self, monthly_theme: str,
                                             daily_theme: str, point_num: int,
                                             phase: str) -> str:
        """生成知识点描述"""
        # 根据阶段生成不同的描述
        descriptions = {
            "基础概念建立": f"这是{monthly_theme}的基础概念之一，理解这个知识点是进一步学习的基础。",
            "核心技能掌握": f"掌握这个{monthly_theme}的核心技能，能够在实际工作中应用。",
            "深度应用探索": f"这个知识点涉及{monthly_theme}的深度应用，帮助你解决复杂问题。",
            "成果整合展示": f"整合学习成果，展示你对{monthly_theme}的全面理解。"
        }
        
        base_desc = descriptions.get(phase, f"关于{monthly_theme}的重要知识点")
        
        return f"{base_desc} 重点关注{daily_theme}的核心内容。"
    
    def _generate_learning_objectives(self, theme: str) -> List[str]:
        """生成学习目标"""
        return [
            f"掌握{theme}的核心概念和基本原理",
            f"能够应用{theme}的基本方法和技巧",
            f"理解{theme}在实际工作中的应用场景",
            f"建立{theme}的知识体系框架",
            f"能够解决{theme}相关的常见问题"
        ]
    
    def export_to_json(self, plan: Dict, output_file: str):
        """将计划导出为JSON文件"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)
    
    def export_to_markdown(self, plan: Dict, output_file: str):
        """将计划导出为Markdown文件"""
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("# 月度学习计划\n\n")
            
            # 元数据
            metadata = plan['metadata']
            f.write(f"## 计划概览\n\n")
            f.write(f"- **技能名称**: {metadata['skill_name']}\n")
            f.write(f"- **年份**: {metadata['year']}\n")
            f.write(f"- **学习强度**: {metadata['intensity']}\n")
            f.write(f"- **总月数**: {metadata['total_months']}\n")
            f.write(f"- **总天数**: {metadata['total_days']}\n")
            f.write(f"- **生成时间**: {metadata['generated_at']}\n\n")
            
            # 月度主题
            f.write("## 月度主题\n\n")
            for theme in plan['monthly_themes']:
                f.write(f"- **{theme['month_name']}**: {theme['theme']}\n")
            f.write("\n")
            
            # 详细计划
            for month_key, month_plan in plan['monthly_plans'].items():
                month_info = month_plan['month_info']
                f.write(f"## {month_info['month_name']}: {month_info['theme']}\n\n")
                
                f.write(f"### 学习目标\n\n")
                for obj in month_plan['learning_objectives']:
                    f.write(f"- {obj}\n")
                f.write("\n")
                
                f.write(f"### 每周安排\n\n")
                for week_key, week_plan in month_plan['weekly_plans'].items():
                    f.write(f"#### {week_key}: {week_plan['phase']}\n\n")
                    f.write(f"**学习重点**: {week_plan['focus']}\n\n")
                    
                    for daily in week_plan['daily_plans']:
                        f.write(f"- **{daily['date']} ({daily['weekday_name']})**: {daily['daily_theme']}\n")
                        f.write(f"  - 学习目标: {daily['learning_objective']}\n")
                        f.write(f"  - 学习时长: {daily['learning_minutes']}分钟\n")
                        f.write(f"  - 知识点数: {len(daily['knowledge_points'])}个\n")
                    f.write("\n")
    
    def print_summary(self, plan: Dict):
        """打印计划摘要"""
        metadata = plan['metadata']
        
        print("=" * 60)
        print(f"📅 月度学习计划摘要 - {metadata['year']}年")
        print("=" * 60)
        print(f"技能名称: {metadata['skill_name']}")
        print(f"学习强度: {metadata['intensity']}")
        print(f"总月数: {metadata['total_months']}")
        print(f"总天数: {metadata['total_days']}")
        print(f"生成时间: {metadata['generated_at']}")
        print()
        
        print("📖 月度主题:")
        for theme in plan['monthly_themes']:
            print(f"  {theme['month_name']}: {theme['theme']}")
        print()


# 命令行接口
def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='生成月度学习计划')
    parser.add_argument('--themes', type=str, required=True,
                       help='月度主题，格式: "4月：红酒学习\\n5月：投资学习"')
    parser.add_argument('--intensity', choices=['easy', 'standard', 'intensive'],
                       default='standard', help='学习强度')
    parser.add_argument('--year', type=int, default=None,
                       help='计划年份，默认为当前年份')
    parser.add_argument('--output-json', type=str, default='learning_plan.json',
                       help='JSON输出文件路径')
    parser.add_argument('--output-md', type=str, default='learning_plan.md',
                       help='Markdown输出文件路径')
    parser.add_argument('--summary', action='store_true',
                       help='打印计划摘要')
    
    args = parser.parse_args()
    
    # 创建生成器
    generator = MonthlyLearningPlanGenerator(year=args.year)
    
    try:
        # 生成计划
        plan = generator.generate_plan(args.themes, args.intensity)
        
        # 导出文件
        generator.export_to_json(plan, args.output_json)
        generator.export_to_markdown(plan, args.output_md)
        
        # 打印摘要
        if args.summary:
            generator.print_summary(plan)
        
        print(f"✅ 学习计划生成完成！")
        print(f"📁 JSON文件: {args.output_json}")
        print(f"📁 Markdown文件: {args.output_md}")
        
        # 显示第一个月的第一天计划作为示例
        first_month_key = list(plan['monthly_plans'].keys())[0]
        first_daily_plan = plan['monthly_plans'][first_month_key]['daily_plans'][0]
        
        print(f"\n📅 示例计划（{first_daily_plan['date']}）:")
        print(f"  主题: {first_daily_plan['daily_theme']}")
        print(f"  学习时长: {first_daily_plan['learning_minutes']}分钟")
        print(f"  知识点数: {len(first_daily_plan['knowledge_points'])}个")
        
    except ValueError as e:
        print(f"❌ 错误: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())