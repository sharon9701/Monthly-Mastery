# 多维表格结构设计参考

## 表格设计原则

### 核心目标
1. **学习进度可视化**：清晰展示学习计划和完成情况
2. **知识沉淀**：系统化保存学习内容和收获
3. **数据分析**：支持学习效果分析和优化
4. **用户体验**：界面友好，操作简便

### 设计原则
- **完整性**：包含学习过程中的所有关键信息
- **结构清晰**：字段分类明确，逻辑关系清晰
- **扩展性**：支持未来功能扩展
- **实用性**：满足实际使用需求

## 基础表格结构

### 核心字段设计

| 字段名称 | 字段类型 | 必填 | 说明 | 示例 |
|---------|---------|------|------|------|
| **学习ID** | 自动编号 | 是 | 唯一标识符 | LM-2026-04-001 |
| **月份** | 单选 | 是 | 所属月份 | 4月、5月、6月 |
| **学习主题** | 文本 | 是 | 月度学习主题 | 红酒学习、投资学习 |
| **周次** | 数字 | 是 | 第几周 | 1、2、3、4 |
| **日期** | 日期 | 是 | 学习日期 | 2026-04-03 |
| **星期** | 单选 | 是 | 星期几 | 周一、周二、周三 |
| **当日主题** | 文本 | 是 | 当日学习主题 | 认识葡萄品种 |
| **核心知识点** | 多行文本 | 是 | 结构化知识点 | 1. 赤霞珠特点...<br>2. 黑皮诺特点... |
| **学习目标** | 多行文本 | 是 | 具体学习目标 | 掌握三种葡萄品种的特点和区别 |
| **学习时长** | 数字 | 是 | 建议学习时间（分钟） | 30 |
| **配图链接** | URL | 否 | 配图链接 | https://example.com/image.jpg |
| **引用链接** | URL列表 | 否 | 参考资料链接 | [链接1](url1)<br>[链接2](url2) |
| **完成状态** | 单选 | 是 | 学习完成状态 | 未开始、进行中、已完成 |
| **掌握程度** | 单选 | 是 | 知识掌握程度 | 未掌握、基本掌握、熟练掌握 |
| **完成时间** | 日期时间 | 否 | 实际完成时间 | 2026-04-03 08:30 |
| **学习笔记** | 多行文本 | 否 | 用户学习笔记 | 今天学习了... |
| **疑问反馈** | 多行文本 | 否 | 学习过程中的疑问 | 对...概念不太理解 |
| **难度评级** | 单选 | 否 | 学习内容难度 | 简单、中等、困难 |
| **兴趣评级** | 单选 | 否 | 学习内容兴趣度 | 低、中、高 |

### 扩展字段（可选）

| 字段名称 | 字段类型 | 说明 |
|---------|---------|------|
| **标签** | 多选 | 知识点分类标签 |
| **关联主题** | 关联字段 | 关联其他学习主题 |
| **项目实践** | 多行文本 | 实践项目描述 |
| **成果展示** | 附件 | 学习成果文件 |
| **学习环境** | 单选 | 学习地点/环境 |
| **专注度** | 数字 | 学习专注度评分 |
| **复习频率** | 单选 | 需要复习的频率 |
| **应用场景** | 多行文本 | 实际应用场景描述 |

## 不同平台的具体实现

### 1. 飞书多维表格

#### 表格创建
```python
# 飞书多维表格API调用示例
def create_feishu_table(access_token):
    url = "https://open.feishu.cn/open-apis/bitable/v1/apps"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    data = {
        "name": "月度学习计划表",
        "folder_token": "空间文件夹token",
        "tables": [
            {
                "name": "学习计划",
                "fields": [
                    {
                        "field_name": "学习ID",
                        "type": 1,  # 自动编号
                        "property": {"auto_serial": {"type": 1}}
                    },
                    {
                        "field_name": "月份",
                        "type": 3,  # 单选
                        "property": {
                            "options": [
                                {"name": "1月", "id": "opt1"},
                                {"name": "2月", "id": "opt2"},
                                # ... 其他月份
                            ]
                        }
                    },
                    # ... 其他字段
                ]
            }
        ]
    }
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()
```

#### 字段类型映射
| 字段类型 | 飞书API类型 | 说明 |
|---------|------------|------|
| 自动编号 | 1 | 自动生成唯一ID |
| 文本 | 2 | 单行文本 |
| 多行文本 | 2 | 多行文本 |
| 数字 | 4 | 数字字段 |
| 单选 | 3 | 单选选项 |
| 多选 | 7 | 多选选项 |
| 日期 | 5 | 日期字段 |
| 人员 | 11 | 人员选择 |
| 附件 | 8 | 文件附件 |
| 链接 | 15 | URL链接 |

### 2. Airtable

#### 表格结构
```python
# Airtable API调用示例
def create_airtable_base(api_key):
    import requests
    
    url = "https://api.airtable.com/v0/meta/bases"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "name": "Monthly Learning Plan",
        "tables": [
            {
                "name": "Learning Schedule",
                "fields": [
                    {"name": "Month", "type": "singleSelect", "options": {"choices": ["January", "February"]}},
                    {"name": "Topic", "type": "singleLineText"},
                    {"name": "Date", "type": "date"},
                    {"name": "Daily Topic", "type": "singleLineText"},
                    {"name": "Key Points", "type": "multilineText"},
                    {"name": "Status", "type": "singleSelect", "options": {"choices": ["Not Started", "In Progress", "Completed"]}},
                    # ... 其他字段
                ]
            }
        ]
    }
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()
```

#### Airtable字段类型
- `singleLineText`: 单行文本
- `multilineText`: 多行文本
- `singleSelect`: 单选
- `multipleSelects`: 多选
- `date`: 日期
- `number`: 数字
- `url`: URL链接
- `attachment`: 附件
- `formula`: 公式

### 3. Notion Database

#### Notion API示例
```python
# Notion Database创建示例
def create_notion_database(api_key, parent_page_id):
    import requests
    
    url = "https://api.notion.com/v1/databases"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }
    
    data = {
        "parent": {"page_id": parent_page_id},
        "title": [{"type": "text", "text": {"content": "学习计划表"}}],
        "properties": {
            "月份": {"select": {"options": []}},
            "主题": {"title": {}},
            "日期": {"date": {}},
            "状态": {"select": {"options": [
                {"name": "未开始", "color": "gray"},
                {"name": "进行中", "color": "blue"},
                {"name": "已完成", "color": "green"}
            ]}},
            # ... 其他字段
        }
    }
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()
```

## 视图设计

### 1. 日历视图
**用途**：按日期查看学习计划

**配置**：
- 分组字段：日期
- 排序：日期升序
- 显示字段：日期、当日主题、状态、学习时长
- 筛选：当前月份、未完成的任务

### 2. 月视图
**用途**：查看月度学习概览

**配置**：
- 分组字段：月份
- 排序：月份升序
- 显示字段：月份、主题、总天数、已完成天数、完成率
- 筛选：特定月份、特定主题

### 3. 周视图
**用途**：查看每周学习安排

**配置**：
- 分组字段：周次
- 排序：周次升序
- 显示字段：周次、本周主题、完成状态、学习进度
- 筛选：当前周、特定周次

### 4. 看板视图
**用途**：任务状态管理

**配置**：
- 分组字段：完成状态
- 排序：日期升序
- 显示字段：当日主题、日期、掌握程度
- 筛选：未开始的任务、进行中的任务

### 5. 表格视图
**用途**：数据查看和编辑

**配置**：
- 排序：日期升序
- 显示字段：所有关键字段
- 筛选：自定义筛选条件

## 自动化同步机制

### 数据同步流程
```
学习计划生成 → 数据格式化 → API调用 → 表格更新 → 状态确认
```

### Python同步脚本示例
```python
import json
import requests
from datetime import datetime

class TableSyncManager:
    """表格同步管理器"""
    
    def __init__(self, platform, config):
        self.platform = platform
        self.config = config
        self.api_clients = {
            'feishu': FeishuClient(config['feishu']),
            'airtable': AirtableClient(config['airtable']),
            'notion': NotionClient(config['notion'])
        }
    
    def sync_learning_plan(self, plan_data):
        """同步学习计划"""
        # 1. 数据格式化
        formatted_data = self._format_data_for_platform(plan_data)
        
        # 2. 批量创建记录
        client = self.api_clients.get(self.platform)
        if not client:
            raise ValueError(f"不支持的平台: {self.platform}")
        
        # 3. 执行同步
        results = []
        for daily_plan in formatted_data:
            try:
                result = client.create_record(daily_plan)
                results.append({
                    'date': daily_plan['date'],
                    'success': True,
                    'record_id': result.get('id')
                })
            except Exception as e:
                results.append({
                    'date': daily_plan['date'],
                    'success': False,
                    'error': str(e)
                })
        
        # 4. 生成同步报告
        sync_report = self._generate_sync_report(results)
        
        return {
            'total': len(results),
            'success': sum(1 for r in results if r['success']),
            'failed': sum(1 for r in results if not r['success']),
            'report': sync_report
        }
    
    def _format_data_for_platform(self, plan_data):
        """根据平台格式化数据"""
        platform_formatters = {
            'feishu': self._format_for_feishu,
            'airtable': self._format_for_airtable,
            'notion': self._format_for_notion
        }
        
        formatter = platform_formatters.get(self.platform)
        if not formatter:
            raise ValueError(f"没有找到平台 {self.platform} 的数据格式化器")
        
        return formatter(plan_data)
    
    def _format_for_feishu(self, plan_data):
        """飞书多维表格数据格式化"""
        formatted_records = []
        
        for month_key, month_plan in plan_data['monthly_plans'].items():
            for daily_plan in month_plan['daily_plans']:
                record = {
                    "fields": {
                        "月份": {"value": month_plan['month_info']['month_name']},
                        "主题": {"value": month_plan['month_info']['theme']},
                        "日期": {"value": daily_plan['date']},
                        "星期": {"value": daily_plan['weekday_name']},
                        "当日主题": {"value": daily_plan['daily_theme']},
                        "核心知识点": {
                            "value": "\n".join([
                                f"{point['id']}. {point['title']}\n{point['description']}"
                                for point in daily_plan['knowledge_points']
                            ])
                        },
                        "学习目标": {"value": daily_plan['learning_objective']},
                        "学习时长": {"value": daily_plan['learning_minutes']},
                        "完成状态": {"value": "未开始"},
                        "掌握程度": {"value": "未掌握"}
                    }
                }
                
                # 添加引用链接
                if daily_plan['knowledge_points']:
                    links = []
                    for point in daily_plan['knowledge_points']:
                        links.extend(point.get('reference_links', []))
                    if links:
                        record["fields"]["引用链接"] = {"value": "\n".join(links)}
                
                formatted_records.append(record)
        
        return formatted_records
    
    def _generate_sync_report(self, results):
        """生成同步报告"""
        success_count = sum(1 for r in results if r['success'])
        failed_count = len(results) - success_count
        
        failed_dates = [r['date'] for r in results if not r['success']]
        
        report = {
            'sync_time': datetime.now().isoformat(),
            'total_records': len(results),
            'success_count': success_count,
            'failed_count': failed_count,
            'success_rate': f"{(success_count/len(results)*100):.1f}%",
            'failed_dates': failed_dates,
            'suggestions': []
        }
        
        if failed_count > 0:
            if failed_count / len(results) > 0.3:
                report['suggestions'].append("同步失败率较高，建议检查API配置")
            if len(failed_dates) > 0:
                report['suggestions'].append(f"需要重新同步的日期: {', '.join(failed_dates[:5])}")
        
        return report
```

## 数据验证和清洗

### 验证规则
```python
class DataValidator:
    """数据验证器"""
    
    @staticmethod
    def validate_daily_plan(plan):
        """验证每日计划数据"""
        errors = []
        
        # 必需字段检查
        required_fields = ['date', 'daily_theme', 'knowledge_points', 'learning_minutes']
        for field in required_fields:
            if field not in plan or not plan[field]:
                errors.append(f"缺少必需字段: {field}")
        
        # 日期格式验证
        if 'date' in plan:
            try:
                datetime.fromisoformat(plan['date'])
            except ValueError:
                errors.append("日期格式不正确，应为 YYYY-MM-DD")
        
        # 学习时长验证
        if 'learning_minutes' in plan:
            if not isinstance(plan['learning_minutes'], (int, float)):
                errors.append("学习时长应为数字")
            elif plan['learning_minutes'] <= 0:
                errors.append("学习时长应大于0")
            elif plan['learning_minutes'] > 120:
                errors.append("学习时长不宜超过120分钟")
        
        # 知识点验证
        if 'knowledge_points' in plan:
            if not isinstance(plan['knowledge_points'], list):
                errors.append("知识点应为列表")
            elif len(plan['knowledge_points']) == 0:
                errors.append("至少需要一个知识点")
            else:
                for i, point in enumerate(plan['knowledge_points']):
                    if 'title' not in point or not point['title']:
                        errors.append(f"知识点{i+1}缺少标题")
                    if 'description' not in point or not point['description']:
                        errors.append(f"知识点{i+1}缺少描述")
        
        return errors
```

### 数据清洗
```python
class DataCleaner:
    """数据清洗器"""
    
    @staticmethod
    def clean_daily_plan(plan):
        """清洗每日计划数据"""
        cleaned = plan.copy()
        
        # 清理字符串字段
        string_fields = ['daily_theme', 'learning_objective']
        for field in string_fields:
            if field in cleaned and isinstance(cleaned[field], str):
                cleaned[field] = cleaned[field].strip()
        
        # 标准化学习时长
        if 'learning_minutes' in cleaned:
            if isinstance(cleaned['learning_minutes'], str):
                try:
                    cleaned['learning_minutes'] = int(cleaned['learning_minutes'])
                except ValueError:
                    cleaned['learning_minutes'] = 30  # 默认值
            
            # 确保在合理范围内
            cleaned['learning_minutes'] = max(5, min(120, cleaned['learning_minutes']))
        
        # 清理知识点
        if 'knowledge_points' in cleaned and isinstance(cleaned['knowledge_points'], list):
            for point in cleaned['knowledge_points']:
                if 'title' in point and isinstance(point['title'], str):
                    point['title'] = point['title'].strip()
                if 'description' in point and isinstance(point['description'], str):
                    point['description'] = point['description'].strip()
                
                # 清理引用链接
                if 'reference_links' in point and isinstance(point['reference_links'], list):
                    point['reference_links'] = [
                        link.strip() for link in point['reference_links']
                        if link and isinstance(link, str) and link.startswith('http')
                    ]
        
        return cleaned
```

## 错误处理和恢复

### 常见错误及处理
| 错误类型 | 原因 | 处理方案 |
|---------|------|---------|
| **API限制** | 请求频率超限 | 实现请求队列和重试机制 |
| **认证失败** | Token过期或无效 | 自动刷新Token或提示重新授权 |
| **网络错误** | 网络连接问题 | 实现重试机制和本地缓存 |
| **数据格式错误** | 数据不符合API要求 | 加强数据验证和清洗 |
| **权限不足** | 没有操作权限 | 检查权限设置，提示用户授权 |

### 重试机制
```python
import time
from typing import Callable, Any

def retry_with_backoff(
    func: Callable,
    max_retries: int = 3,
    initial_delay: float = 1.0,
    backoff_factor: float = 2.0
) -> Any:
    """带指数退避的重试机制"""
    delay = initial_delay
    
    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            
            print(f"尝试 {attempt + 1} 失败，{delay}秒后重试: {e}")
            time.sleep(delay)
            delay *= backoff_factor
    
    raise Exception("重试次数用尽")
```

### 本地缓存
```python
import json
import os
from datetime import datetime, timedelta

class LocalCache:
    """本地缓存管理器"""
    
    def __init__(self, cache_dir=".cache"):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
    
    def save_plan(self, plan_data, plan_id):
        """保存计划到本地"""
        cache_file = os.path.join(self.cache_dir, f"plan_{plan_id}.json")
        
        cache_data = {
            'plan': plan_data,
            'saved_at': datetime.now().isoformat(),
            'plan_id': plan_id
        }
        
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)
        
        return cache_file
    
    def load_plan(self, plan_id):
        """从本地加载计划"""
        cache_file = os.path.join(self.cache_dir, f"plan_{plan_id}.json")
        
        if not os.path.exists(cache_file):
            return None
        
        with open(cache_file, 'r', encoding='utf-8') as f:
            cache_data = json.load(f)
        
        # 检查缓存是否过期（24小时）
        saved_at = datetime.fromisoformat(cache_data['saved_at'])
        if datetime.now() - saved_at > timedelta(hours=24):
            return None
        
        return cache_data['plan']
    
    def mark_synced(self, plan_id, record_ids):
        """标记已同步的记录"""
        sync_file = os.path.join(self.cache_dir, f"sync_{plan_id}.json")
        
        sync_data = {
            'plan_id': plan_id,
            'synced_at': datetime.now().isoformat(),
            'record_ids': record_ids
        }
        
        with open(sync_file, 'w', encoding='utf-8') as f:
            json.dump(sync_data, f, ensure_ascii=False, indent=2)
```

## 使用示例

### 完整同步流程
```python
# 1. 生成学习计划
generator = MonthlyLearningPlanGenerator(year=2026)
plan = generator.generate_plan("4月：红酒学习\n5月：投资学习", intensity="standard")

# 2. 数据验证和清洗
validator = DataValidator()
cleaner = DataCleaner()

for month_key, month_plan in plan['monthly_plans'].items():
    for daily_plan in month_plan['daily_plans']:
        errors = validator.validate_daily_plan(daily_plan)
        if errors:
            print(f"数据验证错误: {errors}")
            continue
        
        cleaned_plan = cleaner.clean_daily_plan(daily_plan)
        daily_plan.update(cleaned_plan)

# 3. 本地缓存
cache = LocalCache()
cache.save_plan(plan, "2026_plan_001")

# 4. 同步到表格
sync_manager = TableSyncManager(
    platform='feishu',
    config={
        'feishu': {
            'app_id': 'your_app_id',
            'app_secret': 'your_app_secret',
            'table_id': 'your_table_id'
        }
    }
)

result = sync_manager.sync_learning_plan(plan)

# 5. 处理结果
if result['success'] == result['total']:
    print(f"✅ 所有{result['total']}条记录同步成功")
    cache.mark_synced("2026_plan_001", [r['record_id'] for r in result['report']['success_records']])
else:
    print(f"⚠️ 同步完成，成功{result['success']}条，失败{result['failed']}条")
    
    # 保存失败记录
    with open('sync_failures.json', 'w', encoding='utf-8') as f:
        json.dump(result['report']['failed_records'], f, indent=2)
```

### 配置说明
```python
# 配置文件示例
config = {
    'platform': 'feishu',  # 或 'airtable', 'notion'
    'api_config': {
        'feishu': {
            'app_id': 'cli_xxxxxxxx',
            'app_secret': 'xxxxxxxxxxxxxxxx',
            'table_id': 'tblxxxxxxxxxxxxxx'
        },
        'airtable': {
            'api_key': 'patxxxxxxxxxxxx',
            'base_id': 'appxxxxxxxxxxxxx',
            'table_name': '学习计划'
        },
        'notion': {
            'api_key': 'secret_xxxxxxxx',
            'database_id': 'xxxxxxxxxxxxxxxx'
        }
    },
    'sync_settings': {
        'auto_sync': True,
        'sync_interval': 3600,  # 1小时
        'retry_count': 3,
        'cache_enabled': True
    }
}
```

---

## 最佳实践建议

### 1. 数据安全
- 使用环境变量存储API密钥
- 实现访问令牌的自动刷新
- 定期清理本地缓存文件
- 对敏感数据进行加密

### 2. 性能优化
- 批量操作减少API调用次数
- 实现数据缓存减少重复请求
- 使用异步处理提高响应速度
- 定期清理无效数据

### 3. 用户体验
- 提供清晰的错误提示
- 实现进度显示和状态反馈
- 支持手动重试和恢复
- 提供数据导出功能

### 4. 维护性
- 统一的错误处理机制
- 详细的日志记录
- 可配置的平台支持
- 模块化的代码结构

### 5. 扩展性
- 支持多种表格平台
- 灵活的数据字段配置
- 可插拔的同步策略
- 支持自定义数据处理逻辑